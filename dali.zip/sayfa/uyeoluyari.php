<?php

header("Location:https://www.yatakpartnersitesi.net/ucretsiz-partner-bulma-sitesi.html");

die();

function aylar($param){
	
	$aylar = array("", "Ocak", "�ubat", "Mart", "Nisan", "May�s", "Haziran", "Temmuz", "A�ustos", "Eyl�l", "Ekim", "Kas�m", "Aral�k");
	
	if($param){
		return $aylar[$param];
	}
	else {
		for($i = 1; $i<=12; $i++) {
			echo "<option value=\"$i\">$aylar[$i]</option>";
		}
	}
	
}
?>
<html>
<head>
<meta http-equiv="Content-Language" content="tr">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-9">
<title>�ye Ol, <?=_BASLIK?></title>
<meta name="keywords" content="<?=_KEYWORDS?>">
<meta name="description" content="<?=_DESCRIPTION?>">
<meta name="copyright" content="Copyright (c) 2009 <?=_AD?>">
<link rel="stylesheet" href="inc/zd.css" type="text/css" />
<script type="text/javascript" src="inc/jquery.js"></script>
<script type="text/javascript" src="inc/uyeol.js"></script>
<style type="text/css">
	body {
		background:url(img/bg.gif);
	}
</style>
</head>
<body>

<div id="kaydol" align="center">
<table border="0" width="100%" id="table1" cellspacing="0" cellpadding="0" height="100%">
	<tr>
		<td width="16">&nbsp;</td>
		<td width="790" valign="top">
		<table border="0" width="100%" id="table2" cellspacing="0" cellpadding="0">
			<tr>
				<td>
				<table border="0" width="100%" id="table3" cellspacing="0" cellpadding="0">
					<tr>
						<td width="10" background="img/ste_golge_sol.gif">&nbsp;</td>
						<td bgcolor="#FFFFFF">
						<table border="0" width="100%" id="table13" cellspacing="0" cellpadding="0">
							<tr>
								<td>
								<style>

								ul, li {padding: 0px; margin: 0px; list-style-type: none}
								#yeni-header {
									width:770px;
									height:193px;
									background:url(images/header-yeni.jpg) no-repeat;
									margin:0px;
									padding:0px;
								}
								.yeni-header-menu {
									width:770px;
									height:49px;
									padding:144px 0px 0px 0px;
									margin:0px;
								}
								.yeni-header-menu li {
									float:left;
									list-style-type: none;
								}
								.yeni-header-menu img {
									border:none;
								}
									
								</style>
								<div id="yeni-header">
									<div id="yeni-header-menu">
										<div class="yeni-header-menu">

										</div>
									</div>
								</div>
								</td>
							</tr>
							<tr>
								<td height="7">
								<img border="0" src="img/1px.gif" width="1" height="1"></td>
							</tr>
							<tr>
								<td>
								<img border="0" src="img/ic_alan_gri_ust.gif" width="770" height="8"></td>
							</tr>
							<tr>
								<td background="img/ic_alan_gri_bg.gif">
								<table border="0" width="100%" id="table14" cellspacing="0" cellpadding="0">
									<tr>
										<td width="10">&nbsp;</td>
										<td width="200" valign="top">
										<table border="0" width="100%" id="table41" cellspacing="0" cellpadding="0">
											<tr>
												<td>&nbsp;</td>
											</tr>
											<tr>
												<td>
												<img border="0" src="img/uyeadim_arasi2.gif" width="200" height="2"></td>
											</tr>
											<tr>
												<td background="img/uyeadim_secilmeyen.gif" height="33" align="center">
												<img border="0" src="img/uyeol_step_kullanici1.gif" width="98" height="18"></td>
											</tr>
											<tr>
												<td>
												<img border="0" src="img/uyeadim_arasi2.gif" width="200" height="2"></td>
											</tr>
											<tr>
												<td background="img/uyeadim_secilmeyen.gif" align="center" height="33">
												<img border="0" src="img/uyeol_step_genelbilgi1.gif" width="100" height="18"></td>
											</tr>
											<tr>
												<td>
												<img border="0" src="img/uyeadim_arasi2.gif" width="200" height="2"></td>
											</tr>
											<tr>
												<td background="img/uyeadim_secilmeyen.gif" align="center" height="33">
												<img border="0" src="img/uyeol_step_ilgialanlari1.gif" width="83" height="18"></td>
											</tr>
											<tr>
												<td>
												<img border="0" src="img/uyeadim_arasi2.gif" width="200" height="2"></td>
											</tr>
											<tr>
												<td>&nbsp;</td>
											</tr>
										</table>
										</td>
										<td width="6">&nbsp;</td>
										<td width="540" valign="top">
										<form method="POST" action="--WEBBOT-SELF--">

										<table border="0" width="100%" id="table15" cellspacing="0" cellpadding="0">
											<tr>
												<td height="45" background="img/pncere1_a_ust.gif">
												<table border="0" width="100%" id="table40" cellspacing="0" cellpadding="0">
													<tr>
														<td width="20" height="45">&nbsp;</td>
														<td>
														<p class="menu">&nbsp;</td>
														<td width="100" align="right">
														&nbsp;</td>
														<td width="20">&nbsp;</td>
													</tr>
												</table>
												</td>
											</tr>
											<tr>
												<td background="img/pncere1_a_bg.gif">
												<table border="0" width="100%" id="table16" cellspacing="0" cellpadding="0">
													<tr>
														<td>
														<table border="0" width="100%" id="table42" cellspacing="0" cellpadding="0">
															<tr>
																<td width="15">&nbsp;</td>
																<td width="95%" valign="top">
																<table border="0" width="100%" id="table92" cellspacing="0" cellpadding="0">
																	<tr>
																		<td width="13" bgcolor="#AEC9F4" height="6">
																		<img border="0" src="img/1px.gif" width="1" height="1"></td>
																		<td bgcolor="#AEC9F4" height="6">
																		<img border="0" src="img/1px.gif" width="1" height="1"></td>
																		<td width="13" bgcolor="#AEC9F4" height="6">
																		<img border="0" src="img/1px.gif" width="1" height="1"></td>
																	</tr>
																	<tr>
																		<td width="13" bgcolor="#E9F0FC">&nbsp;</td>
																		<td bgcolor="#E9F0FC" align="center">
																		<br>
																		<font face="Tahoma" size="2">
																		Merhaba 
																		�ye 
																		olmadan 
																		�nce 
																		mutlaka 
																		okuyunuz<br>
&nbsp;</font></td>
																		<td width="13" bgcolor="#E9F0FC">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="13" bgcolor="#E9F0FC">&nbsp;</td>
																		<td bgcolor="#E9F0FC">
																		<p class="not" style="text-align:justify;">
	<font face="Tahoma" size="2">�ye olmak istedi�iniz bu site s�radan bir partner sitesi 
	<b>DE��LD�R</b>. Burada bulunan ki�iler �ok farkl� nedenlerle bu siteye �ye olmaktad�r ve bu nedenle 
	<b>KAL�TES�YLE</b> kendini bilen <b>EL�T</b> ki�ilere sitemiz a��kt�r..Burada bulunan ki�iler baz� �eyleri a�t��� ve isteklerini ya�amak istedi�i i�in buradad�r ve kimse kimseyi k���k d���r�c� , rencide edici , sayg�s�zca davran��larda bulunamaz.<br /><br />

Bu sitede baz� partner siteleri gibi <b>S�ZLER� KANDIRMAK ���N SAHTE</b> 
	profiller (�yelikler) a��lmaz. Bu ve bunun gibi benzeri durumlarla kesinlikle kar��la�mazs�n�z. Sistemimiz %100 ger�e�i yakalamak isteyen bir site olup kesinlikle 
	<b>SAHTE</b> �yeliklere yer vermez rastland��� taktirde <b>ED�TOR</b> taraf�ndan s�resiz ve s�n�rs�z olarak IP BANLAMA i�lemine maruz kal�r. Kont�r avc�l��� vs. gibi sa�ma sapan i�ler yapmaya �al��an ki�iler olursa sistemimiz taraf�ndan 
	<b>YASAKLANIR</b>. Unutmay�n her yerde oldu�u gibi bu sitede'de kurallar bununda �tesinde kalite �n plandad�r..<br /><br />

Sistemimizdeki her �ye profili tek tek <b>ED�TOR</b> taraf�ndan incelendikten sonra onaylanma i�lemi ger�ekle�ir. Ne arad���n� bilmeyen ba�tan savma, alelacele , yada merak i�in haz�rlanan gereksiz profiller 
	<b>ED�TOR</b> taraf�ndan onaylanmayacakt�r. Bu y�zden profil bilgilerinizi doldururken 
	<b>L�TFEN</b> �zen g�steriniz. �yelik ad�mlar�nda belirtilen kurallara uyarak profil haz�rlay�n�z..<br /><br />

Sitemizde kaliteli , sayg�l� bir ortamda bulunmak , belirtilen kurallara uyarak 
	<b>KAL�TEL�</b> insanlar�n aras�nda yer almak istiyorsan�z sitemize �ye olabilirsiniz..<br /><br />

YP Y�netimi</font></td>
																		<td width="13" bgcolor="#E9F0FC">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="13" bgcolor="#E9F0FC">&nbsp;</td>
																		<td bgcolor="#E9F0FC">&nbsp;</td>
																		<td width="13" bgcolor="#E9F0FC">&nbsp;</td>
																	</tr>
																</table>
																</td>
																<td width="12">&nbsp;</td>
															</tr>
														</table>
														</td>
													</tr>
													<tr>
														<td height="13">
														<img border="0" src="img/1px.gif" width="1" height="1"></td>
													</tr>
													<tr>
														<td align="right">
														<table border="0" id="table91" cellspacing="0" cellpadding="0">
															<tr>
																<td>
																<a href="javascript:void(0)" onclick="window.location='index.php?sayfa=uyeol'" title="Kaydet ve �lerle"><img border="0" src="img/btn_kaydet_ilerle.gif" width="210" height="40"></a></td>
																<td width="15">&nbsp;</td>
															</tr>
														</table>
														</td>
													</tr>
													<tr>
														<td height="8">
														<img border="0" src="img/1px.gif" width="1" height="1"></td>
													</tr>
												</table>
												</td>
											</tr>
											<tr>
												<td>
														<img border="0" src="img/pncere1_alt.gif" width="540" height="9"></td>
											</tr>
											<tr>
												<td height="12"></td>
											</tr>
											</table>
										</form>
										</td>
										<td width="8">&nbsp;</td>
									</tr>
								</table>
								</td>
							</tr>
							<tr>
								<td>
								<img border="0" src="img/ic_alan_gri_alt.gif" width="770" height="8"></td>
							</tr>
						</table>
						</td>
						<td width="10" background="img/ste_golge_sag.gif">&nbsp;</td>
					</tr>
				</table>
				</td>
			</tr>
			<tr>
				<td background="img/ste_alt2.gif" height="93" valign="top">
				<table border="0" width="100%" id="table4" cellspacing="0" cellpadding="0">
					<tr>
						<td width="25" height="7"></td>
						<td height="7"></td>
						<td width="25" height="7"></td>
					</tr>
					<tr>
						<td width="25" height="29">&nbsp;</td>
						<td height="29">
						<table border="0" id="table6" cellspacing="0" cellpadding="0">
							<tr>
								<td>
								<table border="0" id="table7" cellspacing="0" cellpadding="0">
									<tr>
										<td><b><a class="c" href="index.php">ana sayfa</a></b></td>
										<td width="16">&nbsp;</td>
									</tr>
								</table>
								</td>
								<td width="1">
								<img border="0" src="img/mnu_alt_bol.gif" width="1" height="29"></td>
								<td>
								<table border="0" id="table8" cellspacing="0" cellpadding="0">
									<tr>
										<td width="16">&nbsp;</td>
										<td><b><a class="c" href="index.php?sayfa=okey">okey oyna</a></b></td>
										<td width="16">&nbsp;</td>
									</tr>
								</table>
								</td>
								<td width="1">
								<img border="0" src="img/mnu_alt_bol.gif" width="1" height="29"></td>
								<td>
								<table border="0" id="table9" cellspacing="0" cellpadding="0">
									<tr>
										<td width="16">&nbsp;</td>
										<td><b><a class="c" href="index.php?sayfa=sohbet">sohbet et</a></b></td>
										<td width="16">&nbsp;</td>
									</tr>
								</table>
								</td>
								<td width="1">
								<img border="0" src="img/mnu_alt_bol.gif" width="1" height="29"></td>
								<td>
								<table border="0" id="table10" cellspacing="0" cellpadding="0">
									<tr>
										<td width="16">&nbsp;</td>
										<td><b><a class="c" href="index.php?sayfa=arkadas_onlineuyeler">online 
										�yeler</a></b></td>
										<td width="16">&nbsp;</td>
									</tr>
								</table>
								</td>
								<td width="1">
								<img border="0" src="img/mnu_alt_bol.gif" width="1" height="29"></td>
								<td>
								<table border="0" id="table11" cellspacing="0" cellpadding="0">
									<tr>
										<td width="16">&nbsp;</td>
										<td><b><a class="c" href="index.php?sayfa=uyelik_yukselt">�yeli�ini 
										y�kselt</a></b></td>
										<td width="16">&nbsp;</td>
									</tr>
								</table>
								</td>
								<td width="1">
								<img border="0" src="img/mnu_alt_bol.gif" width="1" height="29"></td>
								<td>
								<table border="0" id="table12" cellspacing="0" cellpadding="0">
									<tr>
										<td width="16">&nbsp;</td>
										<td><b><a class="c" href="index.php?sayfa=yardimmerkezi">yard�m merkezi</a></b></td>
										<td width="16">&nbsp;</td>
									</tr>
								</table>
								</td>
							</tr>
						</table>
						</td>
						<td width="25" height="29">&nbsp;</td>
					</tr>
					<tr>
						<td width="25" height="10"></td>
						<td height="10"></td>
						<td width="25" height="10"></td>
					</tr>
					<tr>
						<td width="25">&nbsp;</td>
						<td>
						<table border="0" width="100%" id="table5" cellspacing="0" cellpadding="0">
							<tr>
								<td width="150">
								<p class="copyright">Copyright 2010<br>
								<?=_AD?></td>
								<td align="right" valign="bottom">
								<p class="c2"><a class="c1" href="index.php?sayfa=kullanim_sartlari">Kullan�m 
								�artlar�</a>&nbsp; |&nbsp;
								<a class="c1" href="index.php?sayfa=gizlilik_ilkeleri">Gizlilik �lkeleri</a>&nbsp; |&nbsp;
								<a class="c1" href="index.php?sayfa=yardimmaili">Bize Ula��n</a></td>
							</tr>
						</table>
						</td>
						<td width="25">&nbsp;</td>
					</tr>
				</table>
				</td>
			</tr>
			<tr>
				<td bgcolor="#FFFFFF">&nbsp;</td>
			</tr>
		</table>
		</td>
		<td valign="top">
		<table border="0" id="table847" cellspacing="0" cellpadding="0">
			<tr>
				<td width="15" height="156">&nbsp;</td>
				<td width="161" height="156">&nbsp;</td>
			</tr>
			<tr>
				<td width="15">&nbsp;</td>
				<td width="161">
				<?php include("inc/giris-sag2.php"); ?>
				</td>
			</tr>
			<tr>
				<td width="15">&nbsp;</td>
				<td width="161">&nbsp;</td>
			</tr>
			<tr>
				<td width="15">&nbsp;</td>
				<td width="161">&nbsp;</td>
			</tr>
		</table>
		</td>
	</tr>
</table>
</div>

</body>
</html>