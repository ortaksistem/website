<div align="center" style="width:100%;height:100%;background:#fff">
<table border="0" style="border-collapse: collapse" width="100%" cellpadding="0" height="100%">
	<tr>
		<td align="center" background="img/giris_bg_ust.gif" height="63">&nbsp;</td>
	</tr>
	<tr>
		<td align="center" valign="top">
		<table border="0" style="border-collapse: collapse" width="100%" cellpadding="0">
			<tr>
				<td align="center">
				<table border="0" style="border-collapse: collapse" cellpadding="0">
					<tr>
						<td width="753" align="center">
						<table border="0" style="border-collapse: collapse" cellpadding="0">
							<tr>
								<td>
								<img border="0" src="img/giris_1.gif" width="449" height="309"></td>
								<td width="38">&nbsp;</td>
							</tr>
						</table>
						</td>
					</tr>
				</table>
				</td>
			</tr>
			<tr>
				<td align="center" background="img/giris_bg_orta.gif" height="100">
				<table border="0" style="border-collapse: collapse" cellpadding="0">
					<tr>
						<td width="250" valign="top">
						<table border="0" style="border-collapse: collapse" width="100%" cellpadding="0">
							<tr>
								<td>
								<a href="javascript:girisyap()">
								<img border="0" src="img/btn_tr.gif" width="92" height="39"></a></td>
							</tr>
							<tr>
								<td height="8"></td>
							</tr>
							<tr>
								<td>
								<table border="0" style="border-collapse: collapse" width="100%" cellpadding="0">
									<tr>
										<td width="22">&nbsp;</td>
										<td>
										<p class="tx"><a class="tx" href="javascript:girisyap()">
										yatakpartner' e giri� yapabilmek<br>
										i�in 21 ya� ve �zeri olmal�s�n�z</a></td>
										<td width="15">&nbsp;</td>
									</tr>
								</table>
								</td>
							</tr>
						</table>
						</td>
						<td width="253" height="100">
						<img border="0" src="img/giris_arti21.gif" width="253" height="100"></td>
						<td width="250" valign="top">
						<table border="0" style="border-collapse: collapse" width="100%" cellpadding="0">
							<tr>
								<td align="right">
								<a href="javascript:girisyap()">
								<img border="0" src="img/btn_english.gif" width="92" height="39"></a></td>
							</tr>
							<tr>
								<td height="8"></td>
							</tr>
							<tr>
								<td>
								<table border="0" style="border-collapse: collapse" width="100%" cellpadding="0">
									<tr>
										<td width="15">&nbsp;</td>
										<td align="right">
										<p class="tx"><a class="tx" href="javascript:girisyap()">
										Your age must be over 21<br>
										for visiting our site</a></td>
										<td width="22">&nbsp;</td>
									</tr>
								</table>
								</td>
							</tr>
						</table>
						</td>
					</tr>
				</table>
				</td>
			</tr>
			<tr>
				<td align="center">
				<table border="0" style="border-collapse: collapse" cellpadding="0">
					<tr>
						<td width="250">&nbsp;
						</td>
						<td width="253" height="100">
						<img border="0" src="img/giris_arti21_2.gif" width="253" height="100"></td>
						<td width="250">&nbsp;</td>
					</tr>
				</table>
				</td>
			</tr>
			<tr>
				<td align="center">
				<p class="c2">yatakpartner.com, �yelerinin sergiledi�i bilgilerden dolay� herhangi bir bi�imde sorumlu tutulamaz.<br>
copyright 2004 - 2010</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
			</tr>
		</table>
		</td>
	</tr>
	<tr>
		<td align="center" bgcolor="#D22A2A" height="10">
		<img border="0" src="img/1px.gif" width="1" height="1"></td>
	</tr>
</table>
</div>
<div id="a" style="display:none">
<!-- Sayyac counter START v4.3 -->
<script type="text/javascript">
<!--
document.write(unescape("%3Cscript src='" + (("https:" == document.location.protocol) ? "https://" : "http://")
 + "srv.sayyac.net/sa.js?_salogin=yattakpartner&_sav=4.3' type='text/javascript'%3E%3C/script%3E"));
//-->
</script>
<script type="text/javascript">
<!--
sayyac.track('yattakpartner','srv.sayyac.net');
//-->
</script>
<noscript><a href="http://www.sayyac.com/" title=""><img src="http://srv.sayyac.net/sa.gif?_salogin=yattakpartner&amp;_sav=4.3" border="0" alt="" /></a></noscript>
<!-- Sayyac counter END v4.3 --></div>