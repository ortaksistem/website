<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1254">
<title>Yatakpartner - Yatak partner, partner, partner ara, yatak arkadasi, partner bul</title>
</head>

<body>

<table border="0" cellpadding="0" style="border-collapse: collapse" width="101%" height="270">
	<tr>
		<td width="211">&nbsp;</td>
		<td width="642"><b>Bak�m �al��mas� nedeni ile sitemiz k�sa bir s�reli�ine kapal�d�r 
		aksakl�k i�in �z�r dileriz..</b></td>
		<td>&nbsp;</td>
	</tr>
</table>

</body>

</html>