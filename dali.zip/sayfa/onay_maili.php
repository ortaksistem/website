<html>
<head>
<meta http-equiv="Content-Language" content="tr">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-9">
<title>Onay Mailim Gelmedi</title>
<link rel="stylesheet" href="inc/zd.css" type="text/css" />
</head>
<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0">

<table border="0" id="table1" cellspacing="0" cellpadding="0">
	<tr>
		<td width="20">&nbsp;</td>
		<td width="732">&nbsp;</td>
		<td width="20">&nbsp;</td>
	</tr>
	<tr>
		<td width="20">&nbsp;</td>
		<td width="732" background="img/bg_onaymail.gif" height="323" valign="top">
		<table border="0" width="100%" id="table11" cellspacing="0" cellpadding="0">
			<tr>
				<td width="33">&nbsp;</td>
				<td height="49">
				<p class="tit_zdshop_mer">Onay Mailim Gelmedi?</td>
				<td width="33">&nbsp;</td>
			</tr>
			<tr>
				<td width="33">&nbsp;</td>
				<td height="255" valign="top">
				<table border="0" width="100%" id="table12" cellspacing="0" cellpadding="0">
					<tr>
						<td height="18"></td>
					</tr>
					<tr>
						<td>
						<p class="not2_byz">Sitemizde kullan�c�lar email onay� olmadan sitemize �ye olabilmektedirler. Bu y�zden kullan�c�lar�m�z�n email adreslerine onay maili g�nderilmemektedir.</td>
					</tr>
				</table>
				</td>
				<td width="33">&nbsp;</td>
			</tr>
			</table>
		</td>
		<td width="20">&nbsp;</td>
	</tr>
	<tr>
		<td width="20" height="5"></td>
		<td width="732" height="5"></td>
		<td width="20" height="5"></td>
	</tr>
	<tr>
		<td width="20">&nbsp;</td>
		<td width="732" align="right">
		<table border="0" id="table4" cellspacing="0" cellpadding="0">
			<tr>
				<td>
				<p class="not"><a class="not" href="javascript:void(0)">pencereyi kapat</a></td>
				<td width="15">&nbsp;</td>
			</tr>
		</table>
		</td>
		<td width="20">&nbsp;</td>
	</tr>
	<tr>
		<td width="20">&nbsp;</td>
		<td width="732">&nbsp;</td>
		<td width="20">&nbsp;</td>
	</tr>
</table>
</body>
</html>