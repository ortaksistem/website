<?php


session_destroy();

yonlendir("index.php");


?>