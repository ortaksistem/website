<div align="center" style="width:100%;height:580px;background:url(img/20a_bg.png);">

<div align="center">
	<table border="0" style="border-collapse: collapse" cellpadding="0">
		<tr>
			<td width="618">&nbsp;</td>
		</tr>
		<tr>
			<td width="618" height="372" background="img/bg_uyarizemini.png" valign="bottom" align="center">
			<table border="0" style="border-collapse: collapse" cellpadding="0">
				<tr>
					<td><a href="javascript:girisyap();">
					<img border="0" src="img/btn_uyari_turkce.png" width="190" height="90"></a></td>
					<td width="61">&nbsp;</td>
					<td><a href="javascript:girisyap();">
					<img border="0" src="img/btn_uyari_english.png" width="190" height="90"></a></td>
				</tr>
				<tr>
					<td height="45">&nbsp;</td>
					<td width="61" height="45">&nbsp;</td>
					<td height="45">&nbsp;</td>
				</tr>
			</table>
			</td>
		</tr>
		<tr>
			<td width="618" height="7"></td>
		</tr>
		<tr>
			<td width="618" align="center">
			<table border="0" style="border-collapse: collapse" width="100%" cellpadding="0">
				<tr>
					<td width="17">&nbsp;</td>
					<td>
					<table border="0" style="border-collapse: collapse" cellpadding="0">
						<tr>
							<td><a href="#x">
							<img border="0" src="img/20a_alt_link_privacy_policy.png" width="67" height="16"></a></td>
							<td align="center" width="22">
							<p class="arti21_text">-</td>
							<td><a href="#x">
							<img border="0" src="img/20a_alt_link_terms_of_use.png" width="63" height="16"></a></td>
						</tr>
					</table>
					</td>
					<td width="159">
					<img border="0" src="img/20a_copyright.png" width="159" height="16"></td>
					<td width="17">&nbsp;</td>
				</tr>
			</table>
			</td>
		</tr>
		<tr>
			<td width="618" align="center">&nbsp;</td>
		</tr>
	</table>
</div>

</div>
<div id="a" style="display:none">
</div>