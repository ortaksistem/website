<html>
<head>
<meta http-equiv="Content-Language" content="tr">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-9">
<title>Privacy Police</title>
<link rel="stylesheet" href="../inc/ea.css" type="text/css" />
</head>
<body>
<table border="0" style="border-collapse: collapse" cellpadding="0">
	<tr>
		<td width="25" bgcolor="#C6200B" height="6">
		<img border="0" src="../img/1px.gif" width="1" height="1"></td>
		<td width="550" bgcolor="#C6200B" height="6">
		<img border="0" src="../img/1px.gif" width="1" height="1"></td>
		<td width="25" bgcolor="#C6200B" height="6">
		<img border="0" src="../img/1px.gif" width="1" height="1"></td>
	</tr>
	<tr>
		<td width="25" bgcolor="#C6200B" height="11">
		<img border="0" src="../img/1px.gif" width="1" height="1"></td>
		<td width="550" bgcolor="#C6200B" height="11">
		<img border="0" src="../img/1px.gif" width="1" height="1"></td>
		<td width="25" bgcolor="#C6200B" height="11">
		<img border="0" src="../img/1px.gif" width="1" height="1"></td>
	</tr>
	<tr>
		<td width="25" bgcolor="#C6200B">&nbsp;</td>
		<td width="550" bgcolor="#C6200B">
		<font face="Times New Roman" style="font-size: 21pt; font-weight:700" color="#FFFFFF">
		�yelik S�zle�mesi</font></td>
		<td width="25" bgcolor="#C6200B">&nbsp;</td>
	</tr>
	<tr>
		<td width="25" bgcolor="#C6200B">&nbsp;</td>
		<td width="550" bgcolor="#C6200B">
		<font face="Times New Roman" style="font-size: 14pt; " color="#FFFFFF">ErotikAsklar Privacy Policy</font></td>
		<td width="25" bgcolor="#C6200B">&nbsp;</td>
	</tr>
	<tr>
		<td width="25" bgcolor="#C6200B">&nbsp;</td>
		<td width="550" bgcolor="#C6200B">&nbsp;</td>
		<td width="25" bgcolor="#C6200B">&nbsp;</td>
	</tr>
	<tr>
		<td width="25" bgcolor="#AA2222" height="2">
		<img border="0" src="../img/1px.gif" width="1" height="1"></td>
		<td width="550" bgcolor="#AA2222" height="2">
		<img border="0" src="../img/1px.gif" width="1" height="1"></td>
		<td width="25" bgcolor="#AA2222" height="2">
		<img border="0" src="../img/1px.gif" width="1" height="1"></td>
	</tr>
	<tr>
		<td width="25">&nbsp;</td>
		<td width="550">&nbsp;</td>
		<td width="25">&nbsp;</td>
	</tr>
	<tr>
		<td width="25">&nbsp;</td>
		<td width="550">
		<p class="form_txt"><font color="#C6200B"><b>bu popup un geni�ligi 600 
		px</b></font><br>
		<br>
		Section 1.10.32 of &quot;de Finibus Bonorum et Malorum&quot;, 
		written by Cicero in 45 BC<br>
		&quot;Sed ut perspiciatis unde omnis iste natus error sit voluptatem 
		accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab 
		illo inventore veritatis et quasi architecto beatae vitae dicta sunt 
		explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut 
		odit aut fugit, sed quia consequuntur magni dolores eos qui ratione 
		voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum 
		quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam 
		eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat 
		voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam 
		corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? 
		Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse 
		quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo 
		voluptas nulla pariatur?&quot;<br>
		<br>
		1914 translation by H. Rackham<br>
		&quot;But I must explain to you how all this mistaken idea of denouncing 
		pleasure and praising pain was born and I will give you a complete 
		account of the system, and expound the actual teachings of the great 
		explorer of the truth, the master-builder of human happiness. No one 
		rejects, dislikes, or avoids pleasure itself, because it is pleasure, 
		but because those who do not know how to pursue pleasure rationally 
		encounter consequences that are extremely painful. Nor again is there 
		anyone who loves or pursues or desires to obtain pain of itself, because 
		it is pain, but because occasionally circumstances occur in which toil 
		and pain can procure him some great pleasure. To take a trivial example, 
		which of us ever undertakes laborious physical exercise, except to 
		obtain some advantage from it? But who has any right to find fault with 
		a man who chooses to enjoy a pleasure that has no annoying consequences, 
		or one who avoids a pain that produces no resultant pleasure?&quot;<br>
		<br>
		Section 1.10.33 of &quot;de Finibus Bonorum et Malorum&quot;, written by Cicero in 
		45 BC<br>
		&quot;At vero eos et accusamus et iusto odio dignissimos ducimus qui 
		blanditiis praesentium voluptatum deleniti atque corrupti quos dolores 
		et quas molestias excepturi sint occaecati cupiditate non provident, 
		similique sunt in culpa qui officia deserunt mollitia animi, id est 
		laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita 
		distinctio. Nam libero tempore, cum soluta nobis est eligendi optio 
		cumque nihil impedit quo minus id quod maxime placeat facere possimus, 
		omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem 
		quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet 
		ut et voluptates repudiandae sint et molestiae non recusandae. Itaque 
		earum rerum hic tenetur a sapiente delectus, ut aut reiciendis 
		voluptatibus maiores alias consequatur aut perferendis doloribus 
		asperiores repellat.&quot;</td>
		<td width="25">&nbsp;</td>
	</tr>
	<tr>
		<td width="25">&nbsp;</td>
		<td width="550">&nbsp;</td>
		<td width="25">&nbsp;</td>
	</tr>
	<tr>
		<td width="25" height="27" bgcolor="#E6E6E6">&nbsp;</td>
		<td width="550" height="27" bgcolor="#E6E6E6" align="right">
		<a class="c" href="javascript:window.close();">Pencereyi Kapat</a></td>
		<td width="25" height="27" bgcolor="#E6E6E6">&nbsp;</td>
	</tr>
	<tr>
		<td width="25" bgcolor="#C6200B" height="6">
		<img border="0" src="../img/1px.gif" width="1" height="1"></td>
		<td width="550" bgcolor="#C6200B" height="6">
		<img border="0" src="../img/1px.gif" width="1" height="1"></td>
		<td width="25" bgcolor="#C6200B" height="6">
		<img border="0" src="../img/1px.gif" width="1" height="1"></td>
	</tr>
</table>
</body>
</html>