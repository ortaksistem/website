				<table border="0" width="100%" id="table170" cellspacing="0" cellpadding="0">
					<tr>
						<td background="img/kutuduyuru_ust.gif" height="19">&nbsp;</td>
					</tr>
					<tr>
						<td background="img/kutuduyuru_bg.gif" align="center">
						<table border="0" width="100%" id="table171" cellspacing="0" cellpadding="0">
							<tr>
								<td height="8"></td>
							</tr>
							<tr>
								<td align="center">
								<? echo stripslashes(ayar("sag")); ?>
								</td>
							</tr>
							<tr>
								<td>&nbsp;</td>
							</tr>
						</table>
						</td>
					</tr>
					<tr>
						<td>
						<img border="0" src="img/kutuduyuru_alt.gif" width="161" height="7"></td>
					</tr>
				</table>