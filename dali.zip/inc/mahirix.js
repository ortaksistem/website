function yonlendir(url){
	window.location = url;
}
function secenekler(){
	$("div#seceneklerdiv").slideToggle("slow");
}
function filtre(){
	$("div#filtrediv").slideToggle("slow");
}