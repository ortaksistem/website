							<tr>
								<td>
								<table border="0" width="100%" id="table453" cellspacing="0" cellpadding="0">
									<tr>
										<td align="center">
										<a href="<?=_URL?>"><img src="<? echo stripslashes(ayar("logo")); ?>" border="0" /></a></td>
										<td width="500">
										<? echo stripslashes(ayar("logoyani")); ?></td>
									</tr>
								</table>
								</td>
							</tr>
							<tr>
								<td height="4">
								<img border="0" src="img/1px.gif" width="1" height="1"></td>
							</tr>
							<tr>
								<td background="img/bg_mnu2.gif" height="44" align="center">
								<div align="center">
									<table border="0" style="border-collapse: collapse" cellpadding="0">
										<tr>
											<td>
											<a href="index.php?sayfa=okey"><img border="0" src="img/mnu2_okeyoyna.gif" width="102" height="44"></a></td>
											<td width="32">&nbsp;</td>
											<td>
											<a href="index.php?sayfa=gks_uyeler"><img border="0" src="img/mnu2_sohbetet.gif" width="97" height="44"></a></td>
											<td width="32">&nbsp;</td>
											<td>
											<a href="javascript:void(0)" onclick="pencere('index.php?sayfa=online-yeni', '380', '670', 'onlineuyeler', 2, 1, 1);"><img border="0" src="img/mnu2_onlineuyeler.gif" width="120" height="44"></a></td>
											<td width="32">&nbsp;</td>
											<td>
											<a href="index.php?sayfa=uyelik_yukselt"><img border="0" src="img/mnu2_uyeligiyukselt.gif" width="142" height="44"></a></td>
											<td width="32">&nbsp;</td>
											<td>
											<a href="index.php?sayfa=yardimmerkezi"><img border="0" src="img/mnu2_yardimmerkezi.gif" width="133" height="44"></a></td>
											<td width="5">
											&nbsp;</td>
										</tr>
									</table>
								</div>
								</td>
							</tr>
							<tr>
								<td height="4">
								<img border="0" src="img/1px.gif" width="1" height="1"></td>
							</tr>
							<tr>
								<td>
								<img border="0" src="img/ic_alan_gri_ust.gif" width="770" height="8"></td>
							</tr>