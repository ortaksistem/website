﻿<?php

session_destroy();