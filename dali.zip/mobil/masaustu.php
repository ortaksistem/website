﻿<?php

$_SESSION["masaustu"] = 1;

yonlendir("index.php");