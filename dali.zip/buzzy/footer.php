<div class="footer-top"><div class="container clearfix" style="height:32px">&nbsp;</div></div>
 <div class="footer">
        <div class="container">
            <ul class="menu">
                <li>
                    <h4>Kurumsal</h4>
                    <ul>
                        <li><a href="nedir.php">Buzzy Nedir?</a></li>
                        <li><a href="hakkimizda.php">Biz Kimiz?</a></li>
                        <li><a href="iletisim.php">İletişim</a></li>
                    </ul>
                    <div class="footer-logo">
                        <a href="index.php" title="Anasayfa">
                            <img src="Assets/Img/footer-logo.png" /></a>
                    </div>
                </li>
                <li>
                    <h4>Webmaster Araçları</h4>
                    <ul>
                        <li><a href="analiz.php">Site Analiz</a></li>
                        <li><a href="rakiptakip.php">Rakip Takip</a></li>
                        <li><a href="siratakip.php">Sıra Bulucu</a></li>
                        <li><a href="linktakip.php">Link Takip</a></li>
                    </ul>
                </li>
                <li>
                    <h4>Yeniliklerden Haberdar Olun</h4>
                    <div class="bulletin clearfix">
					<form action="javascript:void(0)" method="post">
                        <input type="text" placeholder="e-mail adresiniz.." class="bulletintext" />
                        <input type="submit" class="sendbulletin right" value="" />
					</form>
                    </div>
                    <ul>
                        <li><a href="kullanim-sozlesmesi.php">Kullanım Sözleşmesi</a></li>
                        <li><a href="gizlilik-bildirimi.php">Gizlilik Bildirimi</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container clearfix">
            <div class="left">Copyright® www.buzzy.com  All Rigts Reserved®</div>
        </div>
    </div>