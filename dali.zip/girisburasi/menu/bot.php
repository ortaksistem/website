<a href="index.php" class="logo">Admin paneline ho� geldiniz. (Buraya ��k�� ve bekleyen i�erikler gelicek)</a>
		<ul id="top-navigation">
			<li><span><span><a href="index.php" title="Anasayfa">Anasayfa</a></span></span></li>
			<li><span><span><a href="index.php?sayfa=uye">�ye Y�netimi</a></span></span></li>
			<li><span><span><a href="index.php?sayfa=icerik">��erik Y�netimi</a></span></span></li>
			<li><span><span><a href="index.php?sayfa=satislar">Sat��lar</a></span></span></li>
			<li class="active"><span><span><a href="index.php?sayfa=bot">Bot Y�netimi</a></span></span></li>
			<li><span><span><a href="index.php?sayfa=yonetici">Y�neticiler</a></span></span></li>
			<li><span><span><a href="index.php?sayfa=bakim">Sistem Bak�m�</a></span></span></li>
			<li><span><span><a href="index.php?sayfa=cikis" title="��k�� Yap">G�venli ��k��</a></span></span></li>
		</ul>
	</div>
	<div id="middle">
		<div id="left-column">
			<h3>Bot Men�</h3>
			<ul class="nav">
				<li><a href="index.php?sayfa=bot">Bot Msj G�nder</a></li>
				<li><a href="index.php?sayfa=botkalanlar">Bot Kalan Mailler</a></li>
				<li><a href="index.php?sayfa=botyala">Bot �p Yala</a></li>
				<li><a href="index.php?sayfa=botemail">Email Listesi Al</a></li>
				<li><a href="index.php?sayfa=online">Online Yap</a></li>
				<li><a href="index.php?sayfa=online_liste">Online Listesi Olu�tur</a></li>
				<li><a href="index.php?sayfa=online_liste_sayi">Online Listesi Say�s�</a></li>
				<li><a href="index.php?sayfa=botonayla">Bot ��erikleri Onayla</a></li>
				<li><a href="index.php?sayfa=emailbot">Email Bot Msj� G�nder</a></li>
				<li><a href="index.php?sayfa=emailcek">Email �ek</a></li>
				<li><a href="index.php?sayfa=sifregonderme">�ifre G�nder</a></li>
				<li><a href="index.php?sayfa=botistatistik">�statistik G�r�nt�le</a></li>
			</ul>
			
			<h3>Yarat�c� Men�</h3>
			<ul class="nav">
				<li><a href="index.php?sayfa=uyeyaratici">�ye Yarat�c�</a></li>
			</ul>
		</div>

