<a href="index.php" class="logo">Admin paneline ho� geldiniz. (Buraya ��k�� ve bekleyen i�erikler gelicek)</a>
		<ul id="top-navigation">
			<li><span><span><a href="index.php" title="Anasayfa">Anasayfa</a></span></span></li>
			<li><span><span><a href="index.php?sayfa=uye">�ye Y�netimi</a></span></span></li>
			<li><span><span><a href="index.php?sayfa=icerik">��erik Y�netimi</a></span></span></li>
			<li><span><span><a href="index.php?sayfa=satislar">Sat��lar</a></span></span></li>
			<li><span><span><a href="index.php?sayfa=bot">Bot Y�netimi</a></span></span></li>
			<li class="active"><span><span><a href="index.php?sayfa=yonetici">Y�neticiler</a></span></span></li>
			<li><span><span><a href="index.php?sayfa=bakim">Sistem Bak�m�</a></span></span></li>
			<li><span><span><a href="index.php?sayfa=cikis" title="��k�� Yap">G�venli ��k��</a></span></span></li>
		</ul>
	</div>
	<div id="middle">
		<div id="left-column">
			<h3>Y�neticiler</h3>
			<ul class="nav">
				<li><a href="index.php?sayfa=yonetici">Yeni Ekle</a></li>
				<li><a href="index.php?sayfa=yoneticilistele">Listele</a></li>
			</ul>
		</div>

