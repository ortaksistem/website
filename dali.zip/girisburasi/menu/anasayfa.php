<a href="index.php" class="logo">Admin paneline ho� geldiniz. (Buraya ��k�� ve bekleyen i�erikler gelicek)</a>
		<ul id="top-navigation">
			<li class="active"><span><span><a href="index.php" title="Anasayfa">Anasayfa</a></span></span></li>
			<li><span><span><a href="index.php?sayfa=uye">�ye Y�netimi</a></span></span></li>
			<li><span><span><a href="index.php?sayfa=icerik">��erik Y�netimi</a></span></span></li>
			<li><span><span><a href="index.php?sayfa=satislar">Sat��lar</a></span></span></li>
			<li><span><span><a href="index.php?sayfa=bot">Bot Y�netimi</a></span></span></li>
			<li><span><span><a href="index.php?sayfa=yonetici">Y�neticiler</a></span></span></li>
			<li><span><span><a href="index.php?sayfa=bakim">Sistem Bak�m�</a></span></span></li>
			<li><span><span><a href="index.php?sayfa=cikis" title="��k�� Yap">G�venli ��k��</a></span></span></li>
		</ul>
	</div>
	<div id="middle">
		<div id="left-column">
			<h3>Ana Ayarlar</h3>
			<ul class="nav">
				<li><a href="index.php?sayfa=ayarlar">Genel Site Ayarlar�</a></li>
				<li><a href="index.php?sayfa=seviye">�yelik Seviyeleri</a></li>
				<li><a href="index.php?sayfa=banner">Site Bannerlar�</a></li>
				<li><a href="index.php?sayfa=sifre">�ifre De�i�tir</a></li>
				<li class="last"><a href="index.php?sayfa=cikis">G�venli ��k��</a></li>
				
			</ul>
			
			<h3><a href="javascript:secenekler()" title="G�ster/Gizle">�yelik Se�enekleri</a></h3>
			<div id="seceneklerdiv" style="display:none">
			<ul class="nav">
				<li><a href="index.php?sayfa=secenekler&tur=medeni">Medeni Durumlar</a></li>
				<li><a href="index.php?sayfa=secenekler&tur=kiminle">Kiminle Ya��yor</a></li>
				<li><a href="index.php?sayfa=secenekler&tur=aradigi">Arad��� �li�ki T�r�</a></li>
				<li><a href="index.php?sayfa=secenekler&tur=cinsiyet">Arad��� Cinsiyet T�r�</a></li>
				<li><a href="index.php?sayfa=secenekler&tur=karakter">Karakter �zellikleri</a></li>
				<li><a href="index.php?sayfa=secenekler&tur=boy">Boy</a></li>
				<li><a href="index.php?sayfa=secenekler&tur=kilo">Kilo</a></li>
				<li><a href="index.php?sayfa=secenekler&tur=vucut">V�cut Yap�s�</a></li>
				<li><a href="index.php?sayfa=secenekler&tur=goz">G�z Rengi</a></li>
				<li><a href="index.php?sayfa=secenekler&tur=sac">Sa� Rengi</a></li>
				<li><a href="index.php?sayfa=secenekler&tur=bakimli">Bak�ml� M�?</a></li>
				<li><a href="index.php?sayfa=secenekler&tur=deneyim">�li�ki Deneyimi</a></li>
				<li><a href="index.php?sayfa=secenekler&tur=egitim">E�itim Durumu</a></li>
				<li><a href="index.php?sayfa=secenekler&tur=meslek">Meslek</a></li>
				<li><a href="index.php?sayfa=secenekler&tur=calisma">�al��ma Durumu</a></li>
				<li><a href="index.php?sayfa=secenekler&tur=hobiler">Hobileri</a></li>
				<li><a href="index.php?sayfa=secenekler&tur=begeniler">Be�enileri</a></li>
				<li><a href="index.php?sayfa=secenekler&tur=film">Filmleri</a></li>
				<li><a href="index.php?sayfa=secenekler&tur=tipler">Ho�. Tipler</a></li>
			</ul>
			</div>
			
			<br>
			
			<h3><a href="javascript:filtre()" title="G�ster/Gizle">Filtre Sistemi</a></h3>
			<div id="filtrediv" style="display:none">
			<ul class="nav">
				<li><a href="index.php?sayfa=filtre&tur=nick">Rumuz Filtresi</a></li>
				<li><a href="index.php?sayfa=filtre&tur=mesaj">Mesaj Filtresi</a></li>
				<li><a href="index.php?sayfa=filtre&tur=profil">Profil Filtresi</a></li>
			</ul>
			
			</div>
			
		</div>