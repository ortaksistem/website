<?php


echo date("N");
echo "<br />";
echo date("H");
